# pnmio version 0.4

## I/O interface to the Portable Any Map (PNM) image format

Copyright (C) 2002-2025 Cosmin Truta.

Use, modification and distribution are subject
to the Boost Software License, Version 1.0.
Please see the accompanying license file or
visit https://www.boost.org/LICENSE_1_0.txt

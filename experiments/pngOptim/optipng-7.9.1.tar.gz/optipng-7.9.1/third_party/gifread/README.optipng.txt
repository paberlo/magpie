Name: gifread
Summary: A plain and simple GIF reader
Author: Cosmin Truta
Original author: David Koblas
License: MIT-like; see gifread.h

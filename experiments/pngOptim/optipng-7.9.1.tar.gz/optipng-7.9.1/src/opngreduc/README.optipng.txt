Name: opngreduc
Summary: libpng extension: lossless image reductions
Author: Cosmin Truta
License: the libpng license

Limitations:
- The color palette reductions are implemented only partially.
- The bit depth reductions below 8, for grayscale images, are
  not implemented yet.
